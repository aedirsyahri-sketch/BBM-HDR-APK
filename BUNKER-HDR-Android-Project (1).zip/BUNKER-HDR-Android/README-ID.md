# BUNKER HDR — Proyek Android

- Nama aplikasi: BUNKER HDR
- Application ID dipertahankan: `com.tbliberty27.fuelmanagement`
- Minimum Android: 6.0 (API 23)
- WebView memuat HTML lokal dari `app/src/main/assets/index.html`.
- Storage key HTML dipertahankan: `liberty_bunker_rob_v3`.

## Build APK otomatis
Unggah seluruh isi folder proyek ke root repository GitHub, termasuk folder tersembunyi `.github/workflows`. Buka tab Actions, jalankan workflow **Build BUNKER HDR APK**, lalu unduh artifact `BUNKER-HDR-debug-apk`.

Catatan: ini proyek sumber untuk build dan pengujian, bukan APK yang sudah diuji di perangkat. Data localStorage di Chrome tidak otomatis pindah ke WebView aplikasi; lakukan ekspor Backup JSON dan uji pemulihan sebelum penggunaan operasional. HTML referensi memuat Tailwind CDN dan Google Fonts; sebagian tampilan dapat memerlukan internet pertama kali kecuali aset tersebut dibundel lokal.
