# BUNKER HDR — Android project (revisi keamanan)

Package aplikasi dipertahankan: `com.tbliberty27.fuelmanagement`
Nama aplikasi: `BUNKER HDR`
Versi sumber: `1.3` (versionCode 4)
Kunci penyimpanan HTML dipertahankan: `liberty_bunker_rob_v3`

## Perubahan
- Menetapkan target kompilasi Java dan Kotlin ke JVM 17.
- Menambahkan konfigurasi build Release non-debuggable.
- Mematikan mixed content WebView dan pembukaan popup JavaScript otomatis.
- Menghapus pemanggilan runtime Tailwind CDN dan Google Fonts. CSS Tailwind hasil kompilasi sudah tertanam di `assets/index.html`; font memakai fallback sistem agar UI tidak bergantung pada internet.
- Mempertahankan package, versionCode/versionName, WebView bridge `AndroidBridge.saveFile`, serta storage key lama.

## Build
Gunakan workflow `.github/workflows/android-apk.yml` dari repository root. Workflow Release memerlukan GitHub Actions secrets:
- `BUNKER_KEYSTORE_BASE64`
- `BUNKER_KEYSTORE_PASSWORD`
- `BUNKER_KEY_ALIAS`
- `BUNKER_KEY_PASSWORD`

Jangan pernah mengunggah file keystore atau password ke repository publik. Simpan cadangan keystore secara aman. APK Release yang akan dipakai untuk update selanjutnya harus ditandatangani dengan keystore yang sama.

## Tentang Play Protect
APK sideload dapat tetap memunculkan peringatan Play Protect meskipun sudah ditandatangani. Penandatanganan Release bukan jaminan Google akan menghilangkan peringatan. Jangan menonaktifkan Play Protect untuk melewati pemeriksaan.

## Catatan pengujian
Perubahan sumber ini belum dikompilasi di lingkungan ini karena Android SDK/Gradle tidak tersedia. Jalankan GitHub Actions dan periksa hasil build serta instalasi di perangkat sebelum dipakai operasional.


## AI Office (prototipe terintegrasi)
- Menambahkan tab AI Office dengan lima profil staf (BIMA, ARUNA, NARA, GARDA, SAKA), ruang kerja visual dan Command Center draft lokal.
- Draft AI Office memakai storage key terpisah `bunker_hdr_ai_office_v1`; storage utama `liberty_bunker_rob_v3` tetap dipertahankan.
- AI belum terhubung ke model/backend; instruksi hanya disimpan sebagai draft lokal.
- CSS Tailwind tetap tertanam offline; tidak menambahkan CDN Tailwind atau Google Fonts eksternal.
- Uji backup/restore, semua menu lama, dan build APK sebelum pemakaian operasional.
