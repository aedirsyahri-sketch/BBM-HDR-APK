# BUNKER HDR AI Office — Android Release Project

## Identitas aplikasi baru
- Nama aplikasi Android: BUNKER HDR AI Office
- applicationId / namespace: `com.tbliberty27.bunkerhdraioffice`
- Versi awal: 1.0 (versionCode 1)
- Package aplikasi lama `com.tbliberty27.fuelmanagement` TIDAK diubah. Kedua aplikasi dapat terpasang berdampingan.

## Data kapal dan migrasi
- HTML tetap menggunakan storage key `liberty_bunker_rob_v3` di dalam penyimpanan aplikasi baru. Karena package Android berbeda, penyimpanan lokal aplikasi baru terpisah dari aplikasi lama.
- Untuk memindahkan data, buka aplikasi lama dan ekspor Backup JSON. Di aplikasi baru, buka Input Harian > Backup & Pemulihan Data > Restore Data, lalu pilih file JSON tersebut.
- Restore mengganti data yang ada pada aplikasi baru. Aplikasi baru masih kosong saat pertama dipasang. Periksa dashboard, Master Data, ROB, sounding, transfer, dan Noon Report setelah restore.
- Buat backup baru dari aplikasi baru setelah migrasi berhasil.

## GitHub Actions
Upload file `BUNKER-HDR-AI-OFFICE-Android-Project.zip` ke root repository GitHub. Buat workflow dari file terpisah `build-ai-office-release.yml` pada path `.github/workflows/build-ai-office-release.yml`.

Tambahkan 4 Repository Actions Secrets baru (jangan menimpa secrets aplikasi lama):
- `AI_OFFICE_KEYSTORE_BASE64`: seluruh satu baris isi file `AI-OFFICE-KEYSTORE-BASE64.txt`
- `AI_OFFICE_KEYSTORE_PASSWORD`: password dari `AI-OFFICE-KEYSTORE-CREDENTIALS.txt`
- `AI_OFFICE_KEY_ALIAS`: alias dari file kredensial
- `AI_OFFICE_KEY_PASSWORD`: password kunci dari file kredensial

Jalankan Actions > Build BUNKER HDR AI Office Release > Run workflow. Hasilnya artifact `BUNKER-HDR-AI-Office-release-APK` berisi `app-release.apk`.

## Keystore
Keystore baru dibuat khusus untuk package AI Office. Simpan file `.p12` dan file kredensial di tempat aman secara offline. Jangan commit atau upload file `.p12`, password, atau file Base64 ke repository.

## Catatan fungsi AI
Menu AI Office, profil staf, ruang kantor, dan Command Log draft lokal sudah ada. Command Log saat ini menyimpan draft lokal; koneksi model AI/backend, analisis otomatis, persetujuan nyata, sinkronisasi, dan penjadwalan belum diaktifkan.

## Status validasi
Struktur ZIP, identitas package, file HTML, dan keystore baru telah diperiksa. APK belum dibangun di lingkungan ini; jalankan GitHub Actions dan uji APK pada perangkat sebelum dipakai operasional.
