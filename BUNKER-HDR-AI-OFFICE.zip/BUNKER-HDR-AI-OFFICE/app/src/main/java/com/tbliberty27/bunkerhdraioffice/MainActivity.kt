package com.tbliberty27.bunkerhdraioffice

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var uploadCallback: ValueCallback<Array<Uri>>? = null
    private var saveBytes: ByteArray? = null
    private var saveMime = "application/octet-stream"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        webView = WebView(this)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            builtInZoomControls = false
            displayZoomControls = false
            loadWithOverviewMode = true
            useWideViewPort = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                if (uri.scheme == "file" || uri.scheme == "about") return false
                if (uri.scheme in listOf("http", "https", "mailto", "tel", "whatsapp")) {
                    return try { startActivity(Intent(Intent.ACTION_VIEW, uri)); true }
                    catch (_: Exception) { Toast.makeText(this@MainActivity, "Aplikasi pembuka tautan tidak ditemukan", Toast.LENGTH_SHORT).show(); true }
                }
                return false
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                uploadCallback?.onReceiveValue(null)
                uploadCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
                startActivityForResult(intent, REQ_OPEN)
                return true
            }
        }
        setContentView(webView)
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html") else webView.restoreState(savedInstanceState)
    }

    inner class AndroidBridge {
        @JavascriptInterface fun saveFile(filename: String, mimeType: String, base64: String) {
            try {
                saveBytes = Base64.decode(base64, Base64.DEFAULT)
                saveMime = mimeType.ifBlank { "application/octet-stream" }
                runOnUiThread {
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE); type = saveMime; putExtra(Intent.EXTRA_TITLE, filename)
                    }
                    startActivityForResult(intent, REQ_SAVE)
                }
            } catch (_: Exception) { runOnUiThread { Toast.makeText(this@MainActivity, "Gagal menyiapkan file", Toast.LENGTH_SHORT).show() } }
        }
    }

    @Deprecated("Activity result API retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OPEN) {
            uploadCallback?.onReceiveValue(if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null)
            uploadCallback = null
        } else if (requestCode == REQ_SAVE) {
            if (resultCode == RESULT_OK && data?.data != null && saveBytes != null) {
                try { contentResolver.openOutputStream(data.data!!)?.use { it.write(saveBytes!!) }; Toast.makeText(this, "File berhasil disimpan", Toast.LENGTH_SHORT).show() }
                catch (_: Exception) { Toast.makeText(this, "Gagal menyimpan file", Toast.LENGTH_SHORT).show() }
            }
            saveBytes = null
        }
    }

    override fun onSaveInstanceState(outState: Bundle) { webView.saveState(outState); super.onSaveInstanceState(outState) }
    @Deprecated("Back navigation handled for WebView")
    override fun onBackPressed() { if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed() }
    override fun onDestroy() { if (::webView.isInitialized) { webView.removeJavascriptInterface("AndroidBridge"); webView.destroy() }; super.onDestroy() }

    companion object { private const val REQ_OPEN = 4101; private const val REQ_SAVE = 4102 }
}
