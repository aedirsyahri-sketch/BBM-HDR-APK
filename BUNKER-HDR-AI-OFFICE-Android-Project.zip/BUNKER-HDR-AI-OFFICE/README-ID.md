# BUNKER HDR AI Office — Paket Android Final

## Identitas aplikasi
- Nama aplikasi: BUNKER HDR AI Office
- Package Android baru: `com.tbliberty27.bunkerhdraioffice`
- Package aplikasi lama tetap: `com.tbliberty27.fuelmanagement`
- Keduanya dapat dipasang berdampingan; aplikasi lama tidak ditimpa.
- Penyimpanan data aplikasi baru tetap memakai key `liberty_bunker_rob_v3` di ruang aplikasi barunya sendiri.

## Migrasi data dari aplikasi lama
1. Buka aplikasi BUNKER HDR lama.
2. Masuk ke Input Harian / Backup & Pemulihan Data.
3. Tekan **Backup Data** dan simpan file JSON.
4. Pasang dan buka BUNKER HDR AI Office.
5. Buka **Restore Data**, pilih JSON dari aplikasi lama, lalu setujui pemulihan.
6. Periksa nama kapal di Master Data, ROB semua tanki, sounding/kalibrasi, riwayat transfer, dan Noon Report.
7. Setelah data cocok, buat backup baru dari aplikasi AI Office.

Restore mengganti data yang sedang ada di aplikasi AI Office. Aplikasi lama tidak disentuh. Jangan hapus aplikasi lama sebelum hasil migrasi diperiksa.

## Build APK melalui GitHub Actions
Paket ini menggunakan workflow terpisah `build-ai-office-release.yml`.

1. Upload `BUNKER-HDR-AI-OFFICE-Android-Project.zip` ke root repository GitHub (workflow juga menerima nama lama `BUNKER-HDR-AI-OFFICE.zip`).
2. Letakkan file workflow pada `.github/workflows/build-ai-office-release.yml`.
3. Pastikan empat Repository Secrets khusus AI Office sudah ada:
   - `AI_OFFICE_KEYSTORE_BASE64`
   - `AI_OFFICE_KEYSTORE_PASSWORD`
   - `AI_OFFICE_KEY_ALIAS`
   - `AI_OFFICE_KEY_PASSWORD`
4. Buka Actions → **Build BUNKER HDR AI Office Release** → **Run workflow**.
5. Jika berhasil (hijau), unduh artifact **BUNKER-HDR-AI-Office-release-APK**. Di dalamnya ada `app-release.apk`.

Workflow memasang JDK 17, Android SDK 35, dan Gradle 8.9 sendiri. Karena itu folder `gradle/wrapper` dan file `gradlew` tidak diperlukan untuk jalur build GitHub Actions ini.

## Keamanan
- Jangan upload file `.p12`, file Base64, atau file kredensial ke repository.
- Jangan bagikan nilai Secrets melalui chat atau screenshot.
- Pertahankan secrets aplikasi lama yang berawalan `BUNKER_`; workflow AI Office hanya membaca secrets `AI_OFFICE_`.

## Batas fungsi AI saat ini
- Menu AI Office, ruang kantor, lima profil staf (BIMA, ARUNA, NARA, GARDA, SAKA), dan log perintah draft lokal sudah disertakan.
- Perintah staf saat ini disimpan sebagai draft lokal dan **belum dikirim ke model AI**. Backend AI, jawaban otomatis, sinkronisasi, persetujuan digital, dan penjadwalan belum terhubung.
- Modul BUNKER HDR, backup/restore JSON, dan fitur yang ada pada HTML sumber disertakan. Tetap lakukan uji operasional sebelum dipakai untuk pencatatan resmi.

## Checklist sebelum dipakai
- [ ] APK berhasil dibuat dan tanda tangan diverifikasi oleh workflow.
- [ ] Aplikasi baru terpasang berdampingan dengan aplikasi lama.
- [ ] Backup JSON dari aplikasi lama berhasil di-restore.
- [ ] Cocokkan Master Data, 8 tanki, ROB, tabel sounding, transfer, dan Noon Report.
- [ ] Uji backup ulang, restore, cetak PDF, dan kirim WhatsApp.
